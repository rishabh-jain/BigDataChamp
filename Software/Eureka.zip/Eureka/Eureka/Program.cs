﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EurekaDataManager;

namespace Eureka
{
    

    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("\n\n\t*\t*\t*\tEUREKA!!!!\t*\t*\t*");
            Console.WriteLine("\t---------------------------------------------------------");

            Console.Write("\nPlease enter the userID and shout EUREKA!!! :\t");
            string userID = Console.ReadLine();

            Manager mManager = Manager.getInstance("UserPreference", "userPreference");
            mManager.getUserPreferenceDataByID(userID);
            Console.ReadLine();
        }
    }
}
