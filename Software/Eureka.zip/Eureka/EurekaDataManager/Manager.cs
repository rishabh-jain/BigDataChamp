﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MongoDB.Bson;
using MongoDB.Driver;
using MongoDB.Driver.Builders;

namespace EurekaDataManager
{
    /// <summary>
    /// This class contains the logic to get data based on query
    /// </summary>
    public class Manager
    {
        static Manager _me;

        /// <summary>
        /// Resolve the collection name at runtime
        /// </summary>
        Type mClassName;

        private const string mConnection = "mongodb://localhost"; // connection string
        private const string mDatabaseName = "RipTideEbayData";    // name of the database

        private MongoClient mClient;    // new client based on connection
        private MongoServer mServer;    // mongo server object based on client settings
        private MongoDatabase mDatabase;    // mongo database from selected server
        private MongoCollection mCollection;    // collection from the selected database
        private IMongoQuery mQuery; // marker for Mongo query


        Manager(string mClassName, string mCollectionName)
        {
            this.mClassName = Type.GetType("EurekaDataManager." + mClassName);
            mClient = new MongoClient(mConnection);
            mServer = mClient.GetServer();
            mDatabase = mServer.GetDatabase(mDatabaseName);
            mCollection = mDatabase.GetCollection(this.mClassName, mCollectionName);
        }

        public static Manager getInstance(string mClassName, string mCollectionName)
        {
            if (_me == null)
            {
                _me = new Manager(mClassName, mCollectionName);
            }

            return _me;
        }

        /// <summary>
        /// Get the user preference data based on the user ID
        /// </summary>
        /// <param name="mUserID">User ID</param>
        public void getUserPreferenceDataByID(string mUserID)
        {
            mQuery = Query<UserPreference>.EQ(eq => eq._id, mUserID);
            UserPreference entity = (UserPreference) mCollection.FindOneAs(mClassName, mQuery);

            char[] delimiters = { ' ', ',', '.', '\t', ':' };   // tokenize the items based on these delimiters

            string[] eliminators = { "Antique", "VINTAGE", "SANSKRITI", "INDIAN" };     // eliminate these strings from the token list

            int itemCount = entity.items.Count();

            Console.WriteLine("\n\n" + itemCount + " items were purchased by " + mUserID);

            List<TokenCount> mTokenList = new List<TokenCount>();  // create a dictionary with counter of occurance of all the tokens

            foreach (string item in entity.items)
            {
                string[] mTokens = item.Split(delimiters);  // tokenize the item title

                foreach (string mToken in mTokens)
                {
                    if (eliminators.Contains(mToken))
                    {
                        continue;
                    }
                    if (mTokenList.Find(e => e.token.Equals(mToken)) == null)
                    {
                        TokenCount mTokenEntry = new TokenCount();
                        mTokenEntry.token = mToken;
                        mTokenEntry.count = 1;
                        mTokenList.Add(mTokenEntry);
                    }
                    else
                    {
                        TokenCount mTokenEntry = mTokenList.Find(e => e.token.Equals(mToken));
                        mTokenEntry.count += 1;
                    }
                }
            }

            mTokenList = mTokenList.OrderByDescending(e => e.count).ToList();     // sort the list in descending order

            Console.WriteLine("\n\nToken Count Result\n");

            foreach (var mTokenEntry in mTokenList)
            {
                Console.WriteLine(mTokenEntry.token + "\t" + mTokenEntry.count);
            }
        }
    }
}
