﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EurekaDataManager
{
    /// <summary>
    /// Represents UserPreference Collection properties
    /// </summary>
    class UserPreference
    {
        /// <summary>
        /// Represents id of the user
        /// </summary>
        public string _id { get; set; }

        /// <summary>
        /// Represents array of items purchased
        /// </summary>
        public string[] items { get; set; }


        public string[] cityName { get; set; }
        public string[] stateName { get; set; }
        public string[] countryName { get; set; }
    }

    /// <summary>
    /// Represents the token counter dictionary entry
    /// </summary>
    class TokenCount
    {
        public string token { get; set; }
        public int count { get; set; }
    }
}
